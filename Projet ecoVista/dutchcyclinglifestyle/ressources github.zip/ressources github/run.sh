cd ComfyUI
python main.py
